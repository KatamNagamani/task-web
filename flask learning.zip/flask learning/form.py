# Store this code in 'app.py' file

from flask import Flask, render_template, request,url_for
import sqlite3 

import re


app = Flask(__name__)
app.secret_key = 'your secret key'



@app.route('/')

	


@app.route('/login', methods =['GET', 'POST'])
def login():
	conn = sqlite3.connect('mydb.sqlite')
	cursor = conn.cursor()
	cursor.execute( 'CREATE TABLE IF NOT EXISTS accounts (  username varchar, password varchar,email varchar)') 
	conn.commit()
	
	
	msg = ''
	if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
		email= request.form['email']
		password = request.form['password']
		conn = sqlite3.connect('mydb.sqlite')
		cursor = conn.cursor()
		cursor.execute('SELECT * FROM accounts WHERE (email = ? AND password = ?)', (email, password, ))
		entry=cursor.fetchone()
		if entry:
	
			msg = 'Logged in successfully !'
			return render_template('index.html', msg = msg)
		
		elif request.method == 'POST':
			msg = 'Please fill out the form !'
			return render_template('login.html', msg = msg)
		
		else:
			msg = 'You don.t have account with this details !'
	return render_template('login.html', msg = msg)


@app.route('/register', methods =['GET', 'POST'])
def register():
	msg = ''
	if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form :
		username = request.form['username']
		password = request.form['password']
		email = request.form['email']
		conn = sqlite3.connect('mydb.sqlite')
		cursor = conn.cursor()
		cursor.execute('SELECT * FROM accounts WHERE username = ? AND password = ? AND email = ?' ,(username, password,email ))
		entry = cursor.fetchone()

		conn.commit()
		
		if entry:
			msg = 'Account already exists !'
		
		elif not username or not password or not email:
			msg = 'Please fill out the form !'
		else:
			
			conn = sqlite3.connect('mydb.sqlite')
			cursor = conn.cursor()
			cursor.execute('INSERT INTO accounts (username, password, email)  VALUES(?,?,?)', (username, password, email))
			conn.commit()
			msg = 'You have successfully registered !'
	elif request.method == 'POST':
		msg = 'Please fill out the form !'
	return render_template('register.html', msg = msg)
if __name__ == '__main__':
   app.run(debug=True)