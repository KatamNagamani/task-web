from flask import Flask
import sqlite3
 
app = Flask(__name__)
 


@app.route('/')
def create_table():
    # db = get_db()
    db = sqlite3.connect('example.db')
    cursor = db.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT NOT NULL,
            user_id INTEGER NOT NULL
        )
    ''')
    db.commit()
    db.close()
    return "table created"
 
# Route to create the table and insert data
@app.route('/create/<username>/<int:user_id>')
def route_create_and_insert(username, user_id):
   
 
    # db = get_db()
    db = sqlite3.connect('example.db')
    cursor = db.cursor()
    cursor.execute("SELECT* FROM users  WHERE (username=? AND user_id=?)", (username, user_id))
    data=cursor.fetchone()
    if data is None:
        cursor.execute('INSERT INTO users (username, user_id) VALUES (?, ?)', (username, user_id))
        db.commit()
        db.close()
        return f'Successfully created: {username}, {user_id}'
    else:
        return"already exists"
 
# route to delete the table and delete the data
@app.route('/delete/<username>/<int:user_id>')
def route_and_delete(username, user_id):
   
 
    # db = get_db()
    db = sqlite3.connect('example.db')
    cursor = db.cursor()
    cursor.execute("DELETE FROM users  WHERE  username =? AND user_id= ?",(username,user_id))
    db.commit()
    db.close()
 
    return f'Successfully deleted: {username}, {user_id}'
 
# update the row
 
@app.route('/update/<username>/<int:user_id>')
def route_and_update(username, user_id):
 
    # db = get_db()
    db = sqlite3.connect('example.db')
    cursor = db.cursor()
    cursor.execute("UPDATE users SET username = ? WHERE user_id = ?;",(username, user_id))
    db.commit()
    db.close()
 
    return f'Successfully updated: {username}, {user_id}'
# Route to display a success message and data from the table
 
if __name__ == '__main__':
    app.run(debug=True)
 
