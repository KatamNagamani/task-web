
from flask import Flask, render_template, redirect, request, session,send_from_directory,send_file
# The Session instance is not used for direct access, you should always use flask.session
# from flask_session import Session
import sqlite3
import random
 
app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
app.secret_key = "some_secret_key" 

# Session(app)




@app.route("/")
def home():
   return render_template("home.html")

@app.route("/admin",methods =['GET', 'POST'])
def admin():
	msg = ''
	if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
		email= request.form['email']
		password = request.form['password']
		conn = sqlite3.connect('buses.db')
		cursor = conn.cursor()
		cursor.execute('SELECT * FROM accounts WHERE (email = ? AND password = ?)', (email, password, ))
		entry=cursor.fetchall()
		print("authentication")
		print(entry)
		if entry:
			
	
			msg = 'Logged in successfully !'
			
			return render_template('admin.html', msg = msg)


		else:
			msg = 'You don.t have account with this details !'
	return render_template("admin.html" ,msg=msg)
	
			
			
   



@app.route("/Book",methods =['GET', 'POST'])
def Book():
	conn = sqlite3.connect('buses.db')
	cursor = conn.cursor()
	cursor.execute( 'CREATE TABLE IF NOT EXISTS userdetails (  name TEXT, num INT, date INT)') 
	conn.commit()
	



	msg = ''
	if request.method == 'POST' and 'name' in request.form and 'num' in request.form and 'date' in request.form :
		name=request.form['name']
		num= request.form['num']
		date = request.form['date']
		conn = sqlite3.connect('buses.db')
		cursor = conn.cursor()
		cursor.execute('SELECT * FROM userdetails WHERE (name = ? AND num = ? AND date = ?)' ,(name,num,date))
		entry = cursor.fetchall()
		print("entry")
		print(entry)

		conn.commit()
		if entry:
			msg = 'Already exists !'
			session['name']=name
			session['num']=num
			session['date']=date
			print(session)
		
		
		else:
			conn = sqlite3.connect('buses.db')
			cursor = conn.cursor()
			cursor.execute('INSERT INTO userdetails (name,num,date) VALUES(?,?,?)',(name,num,date))
			conn.commit()
			msg = 'You have successfully completed !'
			session['name']=name
			session['num']=num
			session['date']=date
			print(session)
	
	
	return render_template("Book.html",msg=msg)






@app.route("/search",methods =['GET', 'POST'])
def search():
	conn = sqlite3.connect('buses.db')
	cursor = conn.cursor()
	source_list=cursor.execute("select DISTINCT source from Buses").fetchall()
	destination_list=cursor.execute("select DISTINCT destination from Buses").fetchall()
	
	conn.commit()
	
	
		
	
	return render_template("search.html",source_list=source_list,destination_list=destination_list)

	
	




@app.route('/select_bus',methods =['GET', 'POST'])
def select_bus():
	msg = ''
	if request.method == 'POST' and 'src' in request.form and 'des' in request.form:
		source= request.form['src']
		destination = request.form['des']
		conn = sqlite3.connect('buses.db')
		cursor=conn.cursor()
		cursor.execute('SELECT * FROM Buses WHERE (source = ? AND destination = ?)', (source,destination ))
		entry=cursor.fetchall()
		
		print(entry)
		if entry:
			session["source"]=source
			session["destination"]=destination
			
			# msg = 'Available buses !'
			
			
			return render_template("select_bus.html",msg=msg,entry=entry)

			
		else:
			msg = 'You don.t have buses !'
		conn.close()	
			
		return render_template('select_bus.html',msg=msg,entry=entry)
	
	
@app.route("/booking/<id>", methods =['GET', 'POST'])
# def downloa(path):
#    return send_file('GFG.txt', as_attachment=True)


def booking(id):
	print(id)
	random_num = random.randrange(1, 1000000)
	
	print("bus details")
	conn = sqlite3.connect('buses.db')
	cursor = conn.cursor()
	cursor.execute( 'CREATE TABLE IF NOT EXISTS Book (name TEXT ,num INT ,date INT ,busid INT, price varchar, nos INT ,time INT)') 
	conn.commit()

	print(" table created")
	conn = sqlite3.connect('buses.db')
	cursor=conn.cursor()
	cursor.execute('SELECT * FROM Buses WHERE id=?', (id,))
	bus=cursor.fetchone()
	print(bus)
	print("printing bus details!")
	busid=bus[0]
	print(busid)
	time=bus[3]
	num_seats = bus[5]
	price=bus[4]
	

	
	name = session['name']
	print(name)
	num= session['num']
	date= session['date']
	print(session)
	# conn = sqlite3.connect('mydb.sqlite')
	# cursor=conn.cursor()
	# cursor.execute("SELECT * FROM userdetails WHERE name=(?) AND num=(?) AND date=(?)", (name,num,date))
	# rows = cursor.fetchone()
	# print(rows)
	# name= rows[0]
	# num = rows[1]
	# date=rows[2]

	conn = sqlite3.connect('buses.db')
	cursor = conn.cursor()
	data=cursor.execute("SELECT * FROM Book WHERE name=? AND num=? AND date=? And busid=?", (name,num,date,busid)).fetchall()
	# rows = cursor.fetchone()

	# cursor.execute("INSERT INTO Booked (name,num,date,busid,price,nos,time) VALUES (?,?,?,?,?,?,?)",
    #                          (name,num,date,busid,price,num_seats,time))
	# data=cursor.execute("SELECT*FROM Book").fetchone()
	conn.commit()
	conn.close()
	print("dataa")
	print(data)
	msg=""
	if data:
		conn = sqlite3.connect('buses.db')
		cursor = conn.cursor()
		
		entry=cursor.execute("SELECT * FROM Book WHERE name=? AND num=? AND date=? And busid=?", (name,num,date,busid)).fetchall()
	
		print(entry)
		conn.commit()
		conn.close()

		msg="already exists"
		
		
		return render_template("booking.html",msg=msg,data=entry ,random_num = random_num)
		
		
	else:
		conn = sqlite3.connect('buses.db')
		cursor = conn.cursor()
		cursor.execute("INSERT INTO Book (name,num,date,busid,price,nos,time) VALUES (?,?,?,?,?,?,?)",
                             (name,num,date,busid,price,num_seats,time))
		entry=cursor.execute("SELECT * FROM Book WHERE name=? AND num=? AND date=? And busid=?", (name,num,date,busid)).fetchall()
	# rows = cursor.fetchone()

		print("inserted")
		print(entry)
		conn.commit()
		conn.close()
		
		return render_template("booking.html",data=entry, random_num=random_num)
	
	
	

@app.route('/login', methods =['GET', 'POST'])
def login():
	conn = sqlite3.connect('buses.db')
	cursor = conn.cursor()
	cursor.execute( 'CREATE TABLE IF NOT EXISTS accounts (  username varchar, password varchar,email varchar)') 
	conn.commit()
	
	msg = ''
	if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form :
		username = request.form['username']
		password = request.form['password']
		email = request.form['email']
		conn = sqlite3.connect('buses.db')
		cursor = conn.cursor()
		cursor.execute('SELECT * FROM accounts WHERE username = ? ' ,(username,  ))
		entry = cursor.fetchone()

		conn.commit()
		
		if entry:
			msg = 'Account already exists !'
		
		elif not username or not password or not email:
			msg = 'Please fill out the form !'
		else:
			
			conn = sqlite3.connect('buses.db')
			cursor = conn.cursor()
			cursor.execute('INSERT INTO accounts (username, password, email)  VALUES(?,?,?)', (username, password, email))
			conn.commit()
			msg = 'You have successfully registered !'
	elif request.method == 'POST':
		msg = 'Please fill out the form !'
	# return render_template('register.html', msg = msg)
	
	

	return render_template('login.html',msg=msg)




@app.route('/register', methods =['GET', 'POST'])
def register():
	conn = sqlite3.connect('buses.db')
	cursor = conn.cursor()
	cursor.execute( 'CREATE TABLE IF NOT EXISTS accounts (  username varchar, password varchar,email varchar)') 
	conn.commit()
	
	msg = ''
	if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form :
		username = request.form['username']
		password = request.form['password']
		email = request.form['email']
		conn = sqlite3.connect('buses.db')
		cursor = conn.cursor()
		cursor.execute('SELECT * FROM accounts WHERE username = ? ' ,(username,  ))
		entry = cursor.fetchone()

		conn.commit()
		
		if entry:
			msg = 'Account already exists !'
		
		elif not username or not password or not email:
			msg = 'Please fill out the form !'
		else:
			
			conn = sqlite3.connect('buses.db')
			cursor = conn.cursor()
			cursor.execute('INSERT INTO accounts (username, password, email)  VALUES(?,?,?)', (username, password, email))
			conn.commit()
			msg = 'You have successfully registered !'
	elif request.method == 'POST':
		msg = 'Please fill out the form !'
	return render_template('register.html', msg = msg)
if __name__ == '__main__':
   app.run(debug=True)