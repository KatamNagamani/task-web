from flask import Flask,render_template ,request
app = Flask(__name__)




@app.route("/get_form")
def get_forms():
   return render_template("get_form.html")



@app.route('/get_details' )
def form():
      firstname = request.values.get('fname')
      lastname = request.values.get('lname')
      print(firstname,lastname)
      
      return render_template("two.html",firstname=firstname,lastname=lastname)

   


@app.route("/")
def one_page_name():
   return render_template("doctors.html")



@app.route("/doctors")
 
def one_page():
   doctors = [{"name" : "tom", "age": 30, "state": "Goa", "country": "India"}, 
              {"name" : "jerry", "age": 32, "state": "cheenai", "country": "India"},
                {"name" : "chutki", "age": 20, "state": "delhi", "country": "India"}, 
                {"name" : "pikachu", "age": 24, "state": "hyb", "country": "India"},
                  {"name" : "Doremao", "age": 36, "state": "kerla", "country": "India"} ]
   
   return render_template("doctors.html" , doctors=doctors )




@app.route('/<int:num1>/<int:num2>/<string:operator>')
def hello(num1, num2, operator):
   if operator=='add':
      return  str(num1+num2)
   elif operator=="sub":
      return str(num1-num2)
   elif operator=='mul':
      return str(num1*num2)
   else:
      return 0


if __name__ == '__main__':
   app.run(debug=True)