import sqlite3 
from flask import Flask
app = Flask(__name__)


@app.route('/')

def creat_table( ):
   conn = sqlite3.connect('mydb.sqlite')
   cursor = conn.cursor()
   

   # Create a table
   cursor.execute( 'CREATE TABLE IF NOT EXISTS STUDENTS (name TEXT, rollno INTEGER)') 
   
               
   conn.commit()
   conn.close()
   return 'Table created successfully!' 
@app.route('/create/<name>/<int:rollno>')
def create(name ,rollno):
   conn =sqlite3.connect('mydb.sqlite')
   cursor = conn.cursor()
   cursor.execute('SELECT * FROM STUDENTS  WHERE (name=? AND rollno=?)', (name,rollno))
   entry=cursor.fetchone()
   if entry is None:
      cursor.execute('INSERT INTO STUDENTS ( name ,rollno) VALUES(?,?)',(name,rollno))
      conn.commit()
      conn.close()
      return 'Data created successfully!'
   else:
      return "already exists" 
   
   
@app.route('/update/<name>/<int:rollno>')
def update( name,rollno):
   conn = sqlite3.connect('mydb.sqlite')
   cursor = conn.cursor()
   

   # update a table
   cursor.execute('''UPDATE STUDENTS SET name = ? WHERE rollno=?;''',(name,rollno)) 
               
   conn.commit()
   conn.close()
   return 'updated successfully!' 


@app.route('/delete/<name>/<int:rollno>')
def delete( name,rollno):
   conn = sqlite3.connect('mydb.sqlite')
   cursor = conn.cursor()
   

   # delete a table
   cursor.execute("DELETE FROM STUDENTS WHERE name=? AND rollno=?", (name,rollno)) 
               
   conn.commit()
   conn.close()
   return 'deleted successfully!' 

 
   

if __name__ == '__main__':
   app.run(debug=True)