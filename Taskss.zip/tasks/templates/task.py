from flask import Flask,render_template ,request
app = Flask(__name__)


@app.route("/")
 
def one_page():
   data = [{"para1" : "Raghu Ram was born in Machilipatnam, Andhra Pradesh, along with his twin brother, Rajiv Lakshman.[1][5] His father is a chartered accountant and his mother is a journalist.[1] Ram has a younger sister Supriya Nistala." 
              ,"para2" :"Albert Einstein gets all the credit for discovering the theory of relativity, but the truth is that he relied on conversations with friends and colleagues to refine his concept. And that’s almost always the case."},
                ]
   
   return render_template("task.html" , data=data )






if __name__ == '__main__':
   app.run(debug=True)